using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    public GameObject enemyPrefab; // Reference to the enemy prefab
    public Transform spawnPoint;   // Point where enemies are spawned
    public GameObject[] towers;    // Array of towers
    public int maxEnemies = 20;    // Maximum number of enemies allowed

    private void Awake()
    {
        if (instance == null) instance = this;
        else if (instance != this) Destroy(gameObject);
    }

    void Start()
    {
        StartCoroutine(SpawnEnemies());
    }

    IEnumerator SpawnEnemies()
    {
        while (true)
        {
            if (transform.childCount < maxEnemies)
            {
                Instantiate(enemyPrefab, spawnPoint.position, Quaternion.identity, transform);
            }
            yield return new WaitForSeconds(2f); // spawn every 2 seconds
        }
    }

    public void EnemyReachedGoal(GameObject enemy)
    {
        DestroyATower();
        enemy.GetComponent<Enemy>().Multiply(); // Call multiply method when an enemy reaches the goal
    }

    private void DestroyATower()
    {
        if (towers.Length > 0)
        {
            GameObject towerToDestroy = towers[0]; // Simple logic to destroy the first tower
            Destroy(towerToDestroy);
            towers = GameObject.FindGameObjectsWithTag("Tower"); // Refresh the tower array
        }
    }
}
