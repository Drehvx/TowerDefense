using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject enemyPrefab; // Drag your enemy prefab here in the inspector
    public float spawnInterval = 2.0f; // Time between each spawn
    public float spawnRadius = 5.0f; // Radius around the spawn point to vary spawn locations

    private float timer;

    void Start()
    {
        timer = spawnInterval; // Initialize the timer to the interval at which enemies should spawn
    }

    void Update()
    {
        timer -= Time.deltaTime; // Decrement the timer by the time passed since last frame
        if (timer <= 0)
        {
            SpawnEnemy(); // Spawn an enemy when the timer reaches or goes below zero
            timer = spawnInterval; // Reset the timer to the interval value for continuous spawning
        }
    }

    void SpawnEnemy()
    {
        if (enemyPrefab != null)
        {
            // Calculate a random position within a sphere centered on the spawner's position
            Vector3 spawnPosition = transform.position + Random.insideUnitSphere * spawnRadius;
            spawnPosition.y = transform.position.y; // Adjust y position to prevent spawning in the air or underground

            // Create an enemy at the calculated position with no rotation (Quaternion.identity)
            Instantiate(enemyPrefab, spawnPosition, Quaternion.identity);
        }
    }
}
