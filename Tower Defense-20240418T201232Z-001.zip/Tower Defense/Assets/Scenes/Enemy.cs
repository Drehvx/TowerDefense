using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float speed = 5f;
    public float health = 100f;
    private Transform target;

    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Goal").transform;
    }

    void Update()
    {
        if (target != null)
        {
            transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Goal"))
        {
            GameManager.instance.EnemyReachedGoal(gameObject); // This should call a method that handles what happens when the goal is reached
        }
    }

    public void TakeDamage(float damage)
    {
        health -= damage;
        if (health <= 0)
        {
            Destroy(gameObject); // This destroys the enemy when health is depleted
        }
    }

    public void Multiply()
    {
        Instantiate(gameObject, transform.position + new Vector3(Random.Range(-1f, 1f), 0, Random.Range(-1f, 1f)), Quaternion.identity);
    }
}
