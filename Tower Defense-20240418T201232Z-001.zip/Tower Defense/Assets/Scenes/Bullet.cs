using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed = 20f;  // Speed at which the bullet moves
    private float maxLifetime = 4f;  // Lifetime of the bullet in seconds after which it will self-destruct

    void Start()
    {
        Destroy(gameObject, maxLifetime);  // Destroys the bullet after a set time to avoid memory and performance issues
    }

    void Update()
    {
        // Move the bullet forward along the X-axis
        transform.Translate(Vector3.right * speed * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Enemy"))  // Assumes the enemy objects have the tag "Enemy"
        {
            Destroy(other.gameObject);  // Destroy the enemy on collision
            Destroy(gameObject);  // Destroy the bullet itself to prevent it from continuing to interact with other game objects
        }
    }
}
