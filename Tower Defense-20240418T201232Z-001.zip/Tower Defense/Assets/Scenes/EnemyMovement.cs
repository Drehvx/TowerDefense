using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    public Transform target;  // Assign this in the Inspector with your goal object
    public float moveSpeed = 5.0f;
    public float closeEnoughDistance = 0.5f;  // How close the enemy needs to get to the goal to consider it "reached"

    void Update()
    {
        MoveTowardsTarget();
    }

    void MoveTowardsTarget()
    {
        if (target != null)
        {
            Vector3 direction = (target.position - transform.position).normalized;
            transform.position += direction * moveSpeed * Time.deltaTime;

            // Check if the enemy has reached the target
            if (Vector3.Distance(transform.position, target.position) <= closeEnoughDistance)
            {
                ReachGoal();
            }
        }
    }

    void ReachGoal()
    {
        // Destroy the enemy object when it reaches the goal
        Destroy(gameObject);
    }
}
