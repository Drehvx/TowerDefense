using UnityEngine;

public class BulletSpawner : MonoBehaviour
{
    public GameObject bulletPrefab;  // Assign this in the inspector with your bullet prefab
    public float firingRate = 0.5f;  // Time in seconds between each shot

    private float nextFireTime = 0f;  // Time until the next bullet should be fired

    void Update()
    {
        if (Time.time >= nextFireTime)
        {
            FireBullet();
            nextFireTime = Time.time + firingRate;  // Calculate the next fire time
        }
    }

    void FireBullet()
    {
        Instantiate(bulletPrefab, transform.position, Quaternion.identity);  // Create a bullet instance at the spawner's position
    }
}
