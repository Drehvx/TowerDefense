using UnityEngine;

public class SphereController : MonoBehaviour
{
    public Transform goal; // Drag the goal GameObject into this field in the inspector
    public float speed = 5.0f; // Adjust speed as necessary

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        Vector3 direction = (goal.position - transform.position).normalized;
        rb.AddForce(direction * speed);
    }
}
