using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float speed = 15f;   // Speed at which the projectile moves
    public float damage = 25f;  // Damage dealt by the projectile
    private Transform target;   // The current target of the projectile

    // Call this method from the tower when creating a projectile to set its target
    public void SetTarget(Transform newTarget)
    {
        target = newTarget;
    }

    void Update()
    {
        if (target == null)
        {
            Destroy(gameObject); // Destroy the projectile if the target is no longer valid
            return;
        }

        Vector3 direction = target.position - transform.position;
        float distanceThisFrame = speed * Time.deltaTime;

        // Check if we hit the enemy
        if (direction.magnitude <= distanceThisFrame)
        {
            HitTarget();
            return;
        }

        // Move the projectile towards the target
        transform.Translate(direction.normalized * distanceThisFrame, Space.World);
        transform.LookAt(target);
    }

    void HitTarget()
    {
        if (target != null)
        {
            Enemy enemy = target.GetComponent<Enemy>();
            if (enemy != null)
            {
                enemy.TakeDamage(damage);
            }
        }

        Destroy(gameObject); // Destroy the projectile after hitting the target
    }
}
